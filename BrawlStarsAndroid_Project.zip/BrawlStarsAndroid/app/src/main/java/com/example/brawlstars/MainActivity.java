package com.example.brawlstars;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        setContentView(new GameView());
    }

    static class Shot {
        float x, y, vx, vy, damage;
        Shot(float x, float y, float vx, float vy, float damage) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.damage=damage;
        }
    }

    static class Bot {
        float x,y,r=18,hp=50,maxHp=50,speed=2,damage=12,face;
        boolean alive=true;
        int cooldown=0,timer=0,respawn=0;
        ArrayList<Shot> shots = new ArrayList<>();
        Bot(float x,float y) { this.x=x; this.y=y; }
    }

    class GameView extends View {
        final int W=800,H=600;
        final Paint p=new Paint(3);
        final Random random=new Random();
        final ArrayList<Bot> bots=new ArrayList<>();
        final ArrayList<Shot> playerShots=new ArrayList<>();
        float px=400,py=300,playerRadius=20,playerHp=100,maxHp=100;
        float playerSpeed=4,playerDamage=20,face=0,ult=0;
        int cooldown=0,rebirths=0,round=1,score=0,kills=0;
        boolean alive=true,ultReady=false;
        boolean moving=false, aiming=false;
        int movePointer=-1,aimPointer=-1;
        float joyBaseX=110,joyBaseY=490,joyX=110,joyY=490,aimX=700,aimY=300;
        long lastFrame=0;

        GameView() {
            super(MainActivity.this);
            setFocusable(true);
            bots.add(new Bot(100,100));
            bots.add(new Bot(700,500));
        }

        float sx, ox, oy;
        void transform(Canvas c) {
            sx=Math.min(getWidth()/800f,getHeight()/600f);
            ox=(getWidth()-800*sx)/2f;
            oy=(getHeight()-600*sx)/2f;
            c.translate(ox,oy);
            c.scale(sx,sx);
        }
        void color(int c) { p.setColor(c); p.setStyle(Paint.Style.FILL); }
        void circle(Canvas c,float x,float y,float r,int col) {
            color(col); c.drawCircle(x,y,r,p);
        }
        void rect(Canvas c,float l,float t,float r,float b,int col) {
            color(col); c.drawRect(l,t,r,b,p);
        }
        void text(Canvas c,String s,float x,float y,float size,int col) {
            color(col); p.setTextSize(size); p.setFakeBoldText(true); c.drawText(s,x,y,p);
        }
        void health(Canvas c,float x,float y,float width,float hp,float max,int height) {
            rect(c,x,y,x+width,y+height,Color.rgb(90,0,0));
            rect(c,x,y,x+width*Math.max(0,hp/max),y+height,Color.rgb(20,220,80));
        }
        float clamp(float v,float lo,float hi) { return Math.max(lo,Math.min(hi,v)); }
        void addSuperShots() {
            for(int i=0;i<16;i++) {
                double a=i*22.5*Math.PI/180.0;
                playerShots.add(new Shot(px,py,(float)Math.cos(a)*14,(float)Math.sin(a)*14,playerDamage*1.5f));
            }
        }
        void startRound() {
            round++;
            bots.clear();
            maxHp+=5;
            playerHp=Math.min(playerHp+20,maxHp);
            int count=Math.min(round+1,5);
            for(int i=0;i<count;i++) bots.add(new Bot(50+random.nextInt(700),50+random.nextInt(500)));
        }
        void respawnPlayer() {
            rebirths++;
            maxHp=100+rebirths*20;
            playerHp=maxHp;
            playerSpeed=4+rebirths*.3f;
            playerDamage=20+rebirths*5;
            alive=true; px=400; py=300;
        }
        void update() {
            if(alive) {
                if(moving) {
                    float dx=joyX-joyBaseX,dy=joyY-joyBaseY,len=(float)Math.hypot(dx,dy);
                    if(len>65){dx=dx/len*65;dy=dy/len*65;len=65;}
                    if(len>8){px+=dx/65*playerSpeed;py+=dy/65*playerSpeed;}
                }
                px=clamp(px,playerRadius,W-playerRadius);
                py=clamp(py,playerRadius,H-playerRadius);
            }
            if(cooldown>0) cooldown--;
            if(aiming && alive && cooldown<=0) {
                float a=(float)Math.atan2(aimY-py,aimX-px);
                face=a;
                playerShots.add(new Shot(px,py,(float)Math.cos(a-.1f)*8,(float)Math.sin(a-.1f)*8,playerDamage));
                playerShots.add(new Shot(px,py,(float)Math.cos(a+.1f)*8,(float)Math.sin(a+.1f)*8,playerDamage));
                cooldown=12; ult+=5;
                if(ult>=100){ultReady=true;ult=0;}
            }

            for(Bot b:bots) {
                if(!b.alive) {
                    if(--b.respawn<=0) { b.alive=true;b.hp=b.maxHp;b.x=50+random.nextInt(700);b.y=50+random.nextInt(500); }
                    continue;
                }
                float dx=px-b.x,dy=py-b.y,dist=(float)Math.hypot(dx,dy);
                if(dist>150 && dist>0){b.x+=dx/dist*b.speed*.8f;b.y+=dy/dist*b.speed*.8f;}
                else if(dist<80 && dist>0){b.x-=dx/dist*b.speed*.5f;b.y-=dy/dist*b.speed*.5f;}
                if(dist>0){b.face=(float)Math.atan2(dy,dx);}
                if(b.cooldown>0)b.cooldown--;
                if(++b.timer>30) {
                    if(random.nextInt(100)<30 && b.cooldown<=0) {
                        float a=(float)Math.atan2(py-b.y,px-b.x)+(random.nextFloat()-.5f)*.4f;
                        b.shots.add(new Shot(b.x,b.y,(float)Math.cos(a)*6,(float)Math.sin(a)*6,b.damage));
                        b.cooldown=20;
                    }
                    b.timer=0;
                }
                for(Shot s:b.shots){s.x+=s.vx;s.y+=s.vy;}
                b.shots.removeIf(s->s.x < -50 || s.x>W+50 || s.y < -50 || s.y>H+50);
            }

            for(Shot s:playerShots){s.x+=s.vx;s.y+=s.vy;}
            playerShots.removeIf(s->s.x < -50 || s.x>W+50 || s.y < -50 || s.y>H+50);

            Iterator<Shot> it=playerShots.iterator();
            while(it.hasNext()) {
                Shot s=it.next();
                boolean hit=false;
                for(Bot b:bots) if(b.alive && Math.hypot(s.x-b.x,s.y-b.y)<b.r+5) {
                    b.hp-=s.damage; hit=true;
                    if(b.hp<=0){b.alive=false;b.respawn=90;kills++;score+=10;}
                    break;
                }
                if(hit)it.remove();
            }
            for(Bot b:bots) {
                Iterator<Shot> bi=b.shots.iterator();
                while(bi.hasNext()) {
                    Shot s=bi.next();
                    if(alive && Math.hypot(s.x-px,s.y-py)<playerRadius+5) {
                        playerHp-=s.damage;bi.remove();
                        if(playerHp<=0){playerHp=0;alive=false;}
                        break;
                    }
                }
            }
            boolean any=false;
            for(Bot b:bots) if(b.alive) any=true;
            if(!any && alive)startRound();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            Canvas c=canvas;
            c.drawColor(Color.BLACK);
            c.save(); transform(c);
            rect(c,0,0,W,H,Color.rgb(15,25,45));
            long now=System.nanoTime();
            if(lastFrame==0)lastFrame=now;
            if(now-lastFrame>=15_000_000L){update();lastFrame=now;}

            for(Bot b:bots) if(b.alive) {
                circle(c,b.x,b.y,b.r,Color.rgb(200,50,50));
                float ex=4*(float)Math.cos(b.face),ey=4*(float)Math.sin(b.face);
                circle(c,b.x-5+ex,b.y-3+ey,3,Color.WHITE);
                circle(c,b.x+5+ex,b.y-3+ey,3,Color.WHITE);
                health(c,b.x-17,b.y-b.r-10,34,b.hp,b.maxHp,4);
                for(Shot s:b.shots)circle(c,s.x,s.y,4,Color.rgb(255,50,50));
            }
            if(alive) {
                circle(c,px,py,playerRadius,Color.rgb(0,150,255));
                float ex=5*(float)Math.cos(face),ey=5*(float)Math.sin(face);
                circle(c,px-5+ex,py-3+ey,4,Color.WHITE);
                circle(c,px+5+ex,py-3+ey,4,Color.WHITE);
                health(c,px-25,py-playerRadius-12,50,playerHp,maxHp,5);
                for(Shot s:playerShots)circle(c,s.x,s.y,5,Color.rgb(255,200,50));
            } else {
                circle(c,400,300,40,Color.rgb(255,215,0));
                text(c,"TAP TO RESPAWN",310,370,22,Color.WHITE);
            }

            // HUD
            text(c,"BRAWL STARS",18,34,22,Color.WHITE);
            text(c,"ROUND "+round+"   SCORE "+score+"   KILLS "+kills,18,62,17,Color.WHITE);
            text(c,"HP "+(int)playerHp+"/"+(int)maxHp,18,88,15,Color.WHITE);

            // Left virtual joystick
            float bx=moving?joyBaseX:110, by=moving?joyBaseY:490;
            circle(c,bx,by,65,Color.argb(115,110,145,180));
            circle(c,bx,by,24,Color.argb(190,190,215,240));
            if(moving) {
                float dx=joyX-joyBaseX,dy=joyY-joyBaseY,len=(float)Math.hypot(dx,dy);
                if(len>65){dx=dx/len*65;dy=dy/len*65;}
                circle(c,joyBaseX+dx,joyBaseY+dy,22,Color.rgb(220,235,250));
            }
            // Fire and super controls
            circle(c,690,500,46,Color.argb(210,190,70,55));
            text(c,"FIRE",665,506,17,Color.WHITE);
            circle(c,690,380,46,ultReady?Color.rgb(255,205,40):Color.argb(190,90,90,115));
            text(c,"SUPER",655,386,15,Color.WHITE);
            text(c,"SUPER "+(int)ult+"%",645,320,13,Color.WHITE);

            c.restore();
            postInvalidateDelayed(16);
        }

        float[] toGame(float x,float y) {
            return new float[]{(x-ox)/sx,(y-oy)/sx};
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float[] pos=toGame(e.getX(),e.getY());
            float x=pos[0],y=pos[1];
            int action=e.getActionMasked(),index=e.getActionIndex(),id=e.getPointerId(index);
            if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN) {
                if(!alive){respawnPlayer();invalidate();return true;}
                if(Math.hypot(x-690,y-380)<52) {
                    if(ultReady){ultReady=false;addSuperShots();}
                    return true;
                }
                if(x<400 && !moving) {
                    moving=true;movePointer=id;joyBaseX=x;joyBaseY=y;joyX=x;joyY=y;
                } else if(x>=400 && !aiming) {
                    aiming=true;aimPointer=id;aimX=x;aimY=y;
                }
                return true;
            }
            if(action==MotionEvent.ACTION_MOVE) {
                for(int i=0;i<e.getPointerCount();i++) {
                    int pid=e.getPointerId(i);
                    float[] q=toGame(e.getX(i),e.getY(i));
                    if(moving && pid==movePointer){joyX=q[0];joyY=q[1];}
                    if(aiming && pid==aimPointer){aimX=q[0];aimY=q[1];}
                }
                return true;
            }
            if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_CANCEL) {
                if(id==movePointer)moving=false;
                if(id==aimPointer)aiming=false;
                return true;
            }
            return true;
        }
    }
}
